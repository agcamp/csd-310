
config = {
    "user": "root",
    "password": "cats81Craddle",
    "host": "127.0.0.1",
    "database": "movies",
    "raise_on_warnings": True
}
